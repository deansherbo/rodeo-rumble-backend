from fastapi import FastAPI
from app.routers import users, athletes, events, bets, odds

app = FastAPI()

app.include_router(users.router, prefix="/users")
app.include_router(athletes.router, prefix="/athletes")
app.include_router(events.router, prefix="/events")
app.include_router(bets.router, prefix="/bets")
app.include_router(odds.router, prefix="/odds")

@app.get("/")
def read_root():
    return {"message": "Welcome to Rodeo Rumble API"}
