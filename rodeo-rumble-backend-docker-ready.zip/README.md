# Rodeo Rumble Backend

FastAPI backend for rodeo betting platform.